package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

import common.StringProcess;
import form.ListFilmForm;
import model.bean.FilmName;
import model.bo.FilmBO;
import model.bo.FilmNameBO;

/**
 * AddFilmAction.java
 *
 * Version 1.0
 *
 * Date: 04-05-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 19-05-2017        	CuongHM4        Create
 */

public class AddFilmAction extends Action{
	/**
	 * Hàm execute AddFilm
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return mapping.findForward
	 * @throws Exception
	 */
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		ListFilmForm listFilmForm2 =(ListFilmForm) form;
		String action=listFilmForm2.getAction();
		System.out.println("aaaaa1");
		
		FilmNameBO filmNameBO = new FilmNameBO();
		ArrayList<FilmName> listFilmName = filmNameBO.getListFilmName();
		listFilmForm2.setListFilmName(listFilmName);
		
		if(null != action && action.equals("検索")){	
			System.out.println("abc"+listFilmForm2.getFilmId());
			System.out.println("xyz"+listFilmForm2.getFilmDayOfYear());
			ActionErrors actionErrors = new ActionErrors();
			
			if(StringProcess.notVaildFilmName(listFilmForm2.getFilmId())){
				actionErrors.add("FilmNameError", new ActionMessage("error.FilmName.trong"));
			}
			
			if(StringProcess.notVaild(listFilmForm2.getFilmDayOfYear())){
				actionErrors.add("FilmDayOfYearError", new ActionMessage("error.FilmDayOfYear.trong"));
			}
			if(StringProcess.checkDayOfYear(listFilmForm2.getFilmDayOfYear())){
				actionErrors.add("FilmDayOfYearError", new ActionMessage("error.FilmDayOfYear.loi"));
			}
			
			if(StringProcess.notVaild(listFilmForm2.getFilmTime())){
				actionErrors.add("FilmTimeError", new ActionMessage("error.FilmTime.trong"));
			}
			if(StringProcess.checkTime(listFilmForm2.getFilmTime())){
				actionErrors.add("FilmTimeError", new ActionMessage("error.FilmTime.loi"));
			}
			
			saveErrors(request, actionErrors);
			if(actionErrors.size()>0){
				return mapping.findForward("addFilmError");
			}
		}
		
		if(null != action && action.equals("検索")){	
			String filmId = listFilmForm2.getFilmId();
			String filmDayOfYear = listFilmForm2.getFilmDayOfYear();
			String filmTime= listFilmForm2.getFilmTime();
			ActionErrors actionErrors = new ActionErrors();
			FilmBO filmBO = new FilmBO();
			System.out.println(listFilmForm2.getFilmId());
			
			saveErrors(request, actionErrors);
			if(actionErrors.size()>0){
				return mapping.findForward("addFilmError");
			}
			else{
				filmBO.addFilm(filmId, filmDayOfYear, filmTime);
				return mapping.findForward("addFilmFinish");
			}
		} else {											
			return mapping.findForward("addFilm");
		}
	}
}
