package model.bo;

import java.util.ArrayList;

import model.bean.FilmName;
import model.dao.FilmNameDAO;

/**
 * FilmNameBO.java
 *
 * Version 1.0
 *
 * Date: 04-05-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-05-2017        	CuongHM4        Create
 */

public class FilmNameBO {
	FilmNameDAO FilmNameDAO = new FilmNameDAO();
	
	/**
	 * Hàm get danh sách tất cả FilmName
	 * @return list
	 */
	public ArrayList<FilmName> getListFilmName() {
		return FilmNameDAO.getListFilmName();
	}
}
