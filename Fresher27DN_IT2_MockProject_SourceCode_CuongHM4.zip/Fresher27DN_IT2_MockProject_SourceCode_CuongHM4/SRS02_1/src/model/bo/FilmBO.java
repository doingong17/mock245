package model.bo;

import java.util.ArrayList;

import model.bean.Film;
import model.dao.FilmDAO;

/**
 * FilmBO.java
 *
 * Version 1.0
 *
 * Date: 04-05-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-05-2017        	CuongHM4        Create
 */

public class FilmBO {
	
	FilmDAO filmDAO = new FilmDAO();
	
	/**
	 * Hàm get danh sách tất cả film
	 * @param offset
	 * @param noOfRecords
	 * @return list
	 */
	public ArrayList<Film> getListFilm(int offset, int noOfRecords) {
		return filmDAO.getListFilm(offset, noOfRecords);
	}
	/*public ArrayList<Film> getListFilm() {
		return filmDAO.getListFilm();
	}*/
	
	/**
	 * Hàm get danh sách film thỏa điều kiện tìm kiếm
	 * @param film
	 * @param offset
	 * @param noOfRecords
	 * @return list
	 */
	public ArrayList<Film> getSearchFilm(Film film, int offset, int noOfRecords){
		return filmDAO.getSearchFilm(film, offset, noOfRecords);
	}
	
	/*public ArrayList<Film> getSearchFilm(Film film){
		return filmDAO.getSearchFilm(film);
	}*/
	
	/**
	 * Hàm thêm 1 phim vào database
	 * @param filmId
	 * @param filmDayOfYear
	 * @param filmTime
	 * @return list
	 */
	public void addFilm(String filmId, String filmDayOfYear, String filmTime){
		filmDAO.addFilm(filmId, filmDayOfYear, filmTime);
	}
}
