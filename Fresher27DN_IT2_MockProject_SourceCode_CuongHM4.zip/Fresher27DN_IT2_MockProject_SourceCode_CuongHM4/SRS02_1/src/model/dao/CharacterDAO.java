package model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.bean.Character;
/**
 * CharacterDAO.java
 *
 * Version 1.0
 *
 * Date: 04-05-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 20-05-2017        	CuongHM4        Create
 */

public class CharacterDAO {
	String url = "jdbc:sqlserver://localhost:1433;databaseName=Film";
	String userName = "sa";
	String password = "12345678";
	Connection connection;
	
	/**
	 * Hàm kết nối database
	 */
	void connect(){
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			connection = DriverManager.getConnection(url, userName, password);
			System.out.println("Ket noi thanh cong");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Ket noi loi");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("Ket noi loi");
		}
	}
	
	/**
	 * Hàm get danh sách tất cả character
	 * @return list
	 */
	public ArrayList<Character> getListCharacter() {
		connect();
		String sql=	"SELECT CharacterId, CharacterName FROM Characters";
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<Character> list = new ArrayList<Character>();
		Character character;
		try {
			while(rs.next()){
				character = new Character();
				character.setCharacterId(rs.getString("CharacterId"));
				character.setCharacterName(rs.getString("CharacterName"));
				list.add(character);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
}
