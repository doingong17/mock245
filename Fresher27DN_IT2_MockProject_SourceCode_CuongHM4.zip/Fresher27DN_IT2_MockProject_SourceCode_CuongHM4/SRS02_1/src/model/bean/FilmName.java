package model.bean;

/**
 * FilmName.java
 *
 * Version 1.0
 *
 * Date: 04-05-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 19-05-2017        	CuongHM4        Create
 */

public class FilmName {
	private String filmId;
	private String filmName;
	private String constructor;
	private String director;
	private String displayTime;
	private String filmImage;
	private String trailer;
	private String characterId;
	private String liberationTimeID;
	
	/**
	 * @return the filmId
	 */
	public String getFilmId() {
		return filmId;
	}
	/**
	 * @param filmId the filmId to set
	 */
	public void setFilmId(String filmId) {
		this.filmId = filmId;
	}
	/**
	 * @return the filmName
	 */
	public String getFilmName() {
		return filmName;
	}
	/**
	 * @param filmName the filmName to set
	 */
	public void setFilmName(String filmName) {
		this.filmName = filmName;
	}
	/**
	 * @return the constructor
	 */
	public String getConstructor() {
		return constructor;
	}
	/**
	 * @param constructor the constructor to set
	 */
	public void setConstructor(String constructor) {
		this.constructor = constructor;
	}
	/**
	 * @return the director
	 */
	public String getDirector() {
		return director;
	}
	/**
	 * @param director the director to set
	 */
	public void setDirector(String director) {
		this.director = director;
	}
	/**
	 * @return the displayTime
	 */
	public String getDisplayTime() {
		return displayTime;
	}
	/**
	 * @param displayTime the displayTime to set
	 */
	public void setDisplayTime(String displayTime) {
		this.displayTime = displayTime;
	}
	/**
	 * @return the filmImage
	 */
	public String getFilmImage() {
		return filmImage;
	}
	/**
	 * @param filmImage the filmImage to set
	 */
	public void setFilmImage(String filmImage) {
		this.filmImage = filmImage;
	}
	/**
	 * @return the trailer
	 */
	public String getTrailer() {
		return trailer;
	}
	/**
	 * @param trailer the trailer to set
	 */
	public void setTrailer(String trailer) {
		this.trailer = trailer;
	}
	/**
	 * @return the characterId
	 */
	public String getCharacterId() {
		return characterId;
	}
	/**
	 * @param characterId the characterId to set
	 */
	public void setCharacterId(String characterId) {
		this.characterId = characterId;
	}
	/**
	 * @return the liberationTimeID
	 */
	public String getLiberationTimeID() {
		return liberationTimeID;
	}
	/**
	 * @param liberationTimeID the liberationTimeID to set
	 */
	public void setLiberationTimeID(String liberationTimeID) {
		this.liberationTimeID = liberationTimeID;
	}
	
}
