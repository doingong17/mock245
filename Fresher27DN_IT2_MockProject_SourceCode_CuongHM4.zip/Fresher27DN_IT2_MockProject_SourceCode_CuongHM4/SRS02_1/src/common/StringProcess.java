package common;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.text.ParseException;

/**
 * StringProcess.java
 *
 * Version 1.0
 *
 * Date: 04-05-2017 
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * 22-05-2017        	CuongHM4        Create
 */

public class StringProcess {
	
	/**
	 * Hàm kiểm tra xâu rỗng hay không
	 * @param s
	 * @return
	 */
	public static boolean notVaild(String s){
		if(s==null || s.length()==0) return true;
		return false;
	}
	
	/**
	 * Hàm kiểm tra đã chọn xâu ngoại trừ xâu mặc định chưa
	 * @param s
	 * @return
	 */
	public static boolean notVaildLiberationTime(String s){
		if("来ている".equals(s)) return true;
		return false;
	}
	
	/**
	 * Hàm kiểm tra đã chọn xâu ngoại trừ xâu mặc định chưa
	 * @param s
	 * @return
	 */
	public static boolean notVaildFilmName(String s){
		if("Doctor-Strange".equals(s)) return true;
		return false;
	}
	
	/**
	 * Hàm kiểm tra xâu rỗng hay không
	 * @param s
	 * @return
	 */
	public static boolean notVaildDayOfWeek(String s){
		if(s==null || s.length()==0) return true;
		return false;
	}
	
	/**
	 * Hàm kiểm tra xâu đã đúng định dạng ngày trong tuần chưa
	 * @param s
	 * @return
	 */
	public static boolean checkDayofWeek(String s){
		if (s.trim().equals("")) {
			return false;
		}
		if("Monday".equals(s.trim())|| "Tuesday".equals(s.trim()) || "Wednesday".equals(s.trim()) || "Thursday".equals(s.trim()) || "Friday".equals(s.trim()) || "Saturday".equals(s.trim()) || "Sunday".equals(s.trim())) return false;
		return true;
	}
	
	/**
	 * Hàm kiểm tra xâu đã đúng định dạng ngày chưa
	 * @param s
	 * @return
	 */
	public static boolean checkDayOfYear(String s) {
		if (s.trim().equals("")) {
			return false;
		} else {
			SimpleDateFormat sdfrmt = new SimpleDateFormat("yyyy/MM/dd");
			sdfrmt.setLenient(false);
			Date javaDate = null;
			try {
				javaDate = sdfrmt.parse(s);
			} catch (ParseException e) {
				return true;
			}
			return false;
		}
	}
	
	/**
	 * Hàm kiểm tra xâu đã đúng định dạng thời gian chưa
	 * @param s
	 * @return
	 */
	public static boolean checkTime(String s) {
		if (s.trim().equals("")) {
			return false;
		} else {
			SimpleDateFormat sdfrmt = new SimpleDateFormat("HH:mm");
			sdfrmt.setLenient(false);
			Date javaTime = null;
			try {
				javaTime = sdfrmt.parse(s);
			} catch (ParseException e) {
				return true;
			}
			return false;
		}
	}
}
